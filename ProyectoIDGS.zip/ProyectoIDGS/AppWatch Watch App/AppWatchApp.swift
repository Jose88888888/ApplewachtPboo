//
//  AppWatchApp.swift
//  AppWatch Watch App
//
//  Created by Jessica Aguilar on 12/08/24.
//

import SwiftUI

@main
struct AppWatch_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
