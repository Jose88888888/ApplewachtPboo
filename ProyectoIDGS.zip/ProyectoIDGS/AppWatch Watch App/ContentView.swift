import SwiftUI
import WatchConnectivity


struct ContentView: View {
    private let fixedLatitude: Double = 20.483553878495336
    private let fixedLongitude: Double = -103.53331936748678
    
    var body: some View {
        VStack {
            Button(action: {
                sendPanicData()
            }) {
                Text("Presionar")
                    .padding(80)
                    .background(Color.red)
                    .foregroundColor(.white)
                    .clipShape(Circle())
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .onAppear {
            WatchSessionManager.shared.activateSession()
        }
    }
    
    func sendPanicData() {
        guard WCSession.default.isReachable else {
            print("La sesión no está activada o el iPhone no está alcanzable")
            return
        }

        let date = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let dateString = dateFormatter.string(from: date)
        
        let panicData: [String: Any] = [
            "date": dateString,
            "latitude": fixedLatitude,
            "longitude": fixedLongitude
        ]
        
        WCSession.default.sendMessage(panicData, replyHandler: nil) { error in
            print("Error al enviar datos: \(error.localizedDescription)")
        }
    }
}
