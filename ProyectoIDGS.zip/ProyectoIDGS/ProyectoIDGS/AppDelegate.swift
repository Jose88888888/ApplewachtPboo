import UIKit
import WatchConnectivity

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        WatchSessionManager.shared.activateSession()
        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Implementación si es necesaria
    func application(_ application: UIApplication, handleWatchKitExtensionRequest userInfo: [String : Any]?, reply: @escaping ([String : Any]?) -> Void) {
            print("Received message from Watch: \(userInfo ?? [:])")
            // Procesa el mensaje aquí
            reply(["status": "received"])
        }
    }
}
