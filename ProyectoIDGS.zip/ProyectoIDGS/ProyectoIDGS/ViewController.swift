import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleReceivedWatchData(_:)), name: NSNotification.Name("ReceivedWatchData"), object: nil)
    }
    
    @objc func handleReceivedWatchData(_ notification: Notification) {
        if let userInfo = notification.userInfo,
           let date = userInfo["date"] as? String,
           let latitude = userInfo["latitude"] as? Double,
           let longitude = userInfo["longitude"] as? Double {
            print("Fecha: \(date), Latitud: \(latitude), Longitud: \(longitude)")
            // Aquí puedes manejar la información como desees
        }
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
}

