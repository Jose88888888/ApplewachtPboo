import Foundation
import WatchConnectivity

class WatchSessionManager: NSObject, WCSessionDelegate {
    static let shared = WatchSessionManager()
    private override init() {
        super.init()
    }

    func activateSession() {
        if WCSession.isSupported() {
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
    }

    // Este método es requerido para manejar la activación de la sesión
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        if let error = error {
            print("Error al activar la sesión: \(error.localizedDescription)")
        } else {
            print("Sesión activada con estado: \(activationState.rawValue)")
        }
    }

    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        if let date = message["date"] as? String,
           let latitude = message["latitude"] as? Double,
           let longitude = message["longitude"] as? Double {
            print("Fecha: \(date), Latitud: \(latitude), Longitud: \(longitude)")
            
            // Envía una notificación con los datos recibidos
            NotificationCenter.default.post(name: NSNotification.Name("ReceivedWatchData"), object: nil, userInfo: message)
        }
    }
    // Implementa los siguientes métodos opcionales según sea necesario
    func session(_ session: WCSession, didReceiveApplicationContext applicationContext: [String : Any] = [:]) {
        // Maneja el contexto de la aplicación
    }

    func session(_ session: WCSession, didReceiveUserInfo userInfo: [String : Any] = [:]) {
        // Maneja la información del usuario
    }

    func session(_ session: WCSession, didReceive file: WCSessionFile) {
        // Maneja archivos recibidos
    }

    func session(_ session: WCSession, didFinish fileTransfer: WCSessionFileTransfer, error: Error?) {
        // Maneja la finalización de la transferencia de archivos
    }

#if os(iOS)
public func sessionDidBecomeInactive(_ session: WCSession) { }
public func sessionDidDeactivate(_ session: WCSession) {
    session.activate()
}
#endif
}
